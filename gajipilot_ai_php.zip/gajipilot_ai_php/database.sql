CREATE DATABASE IF NOT EXISTS gajipilot_ai;
USE gajipilot_ai;

CREATE TABLE IF NOT EXISTS salary_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(100) NOT NULL,
    monthly_salary DECIMAL(10,2) NOT NULL,
    fixed_needs DECIMAL(10,2) NOT NULL,
    existing_debt DECIMAL(10,2) NOT NULL,
    lifestyle_spending DECIMAL(10,2) NOT NULL,
    monthly_savings DECIMAL(10,2) NOT NULL,
    emergency_fund DECIMAL(10,2) NOT NULL,
    dependents INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS commitments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    profile_id INT NOT NULL,
    commitment_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    monthly_amount DECIMAL(10,2) NOT NULL,
    duration_text VARCHAR(100) DEFAULT 'Ongoing',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (profile_id) REFERENCES salary_profiles(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS life_goals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    profile_id INT NOT NULL,
    goal_name VARCHAR(100) NOT NULL,
    target_amount DECIMAL(10,2) NOT NULL,
    current_saved DECIMAL(10,2) NOT NULL DEFAULT 0,
    target_months INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (profile_id) REFERENCES salary_profiles(id) ON DELETE CASCADE
);
