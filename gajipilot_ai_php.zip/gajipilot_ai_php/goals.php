<?php
include "config.php";
include "functions.php";

$profile_id = $_GET['profile_id'] ?? null;
if (!$profile_id) {
    $latest = $conn->query("SELECT id FROM salary_profiles ORDER BY id DESC LIMIT 1")->fetch_assoc();
    $profile_id = $latest['id'] ?? null;
}

if (!$profile_id) {
    header("Location: salary.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_id'])) {
        $delete_id = (int)$_POST['delete_id'];
        $conn->query("DELETE FROM life_goals WHERE id = $delete_id AND profile_id = $profile_id");
    } else {
        $stmt = $conn->prepare("INSERT INTO life_goals (profile_id, goal_name, target_amount, current_saved, target_months) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isddi", $profile_id, $_POST['goal_name'], $_POST['target_amount'], $_POST['current_saved'], $_POST['target_months']);
        $stmt->execute();
    }
}

$goals = $conn->query("SELECT * FROM life_goals WHERE profile_id = $profile_id ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Life Goals - GajiPilot AI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "header.php"; ?>
<main>
    <div class="grid two">
        <div class="card">
            <h2>Life Goals Planner</h2>
            <p class="muted">Plan non-loan goals like wedding, Umrah, education, house deposit, laptop, emergency fund, or small business.</p>

            <form method="POST" class="form">
                <div>
                    <label>Goal Name</label>
                    <input name="goal_name" value="Umrah / Travel" required>
                </div>
                <div>
                    <label>Target Amount</label>
                    <input type="number" step="0.01" name="target_amount" value="6000" required>
                </div>
                <div>
                    <label>Current Saved</label>
                    <input type="number" step="0.01" name="current_saved" value="800" required>
                </div>
                <div>
                    <label>Target Months</label>
                    <input type="number" name="target_months" value="18" required>
                </div>
                <div style="grid-column:1/-1;">
                    <button class="btn primary" type="submit">Add Goal</button>
                </div>
            </form>

            <div style="margin-top:18px;">
                <a class="btn secondary" href="result.php?profile_id=<?php echo $profile_id; ?>">Can I Commit? →</a>
            </div>
        </div>

        <div class="card">
            <h2>Goals to Plan</h2>
            <?php if (empty($goals)): ?>
                <p class="muted">No goals yet. Add one to calculate monthly savings needed.</p>
            <?php endif; ?>

            <?php foreach ($goals as $g): ?>
                <?php $monthly = calculateMonthlyGoal($g); ?>
                <div class="item">
                    <div>
                        <b><?php echo htmlspecialchars($g['goal_name']); ?></b>
                        <div class="muted">
                            Target <?php echo money($g['target_amount']); ?> • Saved <?php echo money($g['current_saved']); ?> • <?php echo (int)$g['target_months']; ?> months
                        </div>
                        <div class="muted"><b>Need <?php echo money($monthly); ?>/month</b></div>
                    </div>
                    <div class="item-actions">
                        <form method="POST" style="margin:0;">
                            <input type="hidden" name="delete_id" value="<?php echo $g['id']; ?>">
                            <button class="delete" type="submit">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</main>
</body>
</html>
