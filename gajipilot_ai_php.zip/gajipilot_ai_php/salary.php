<?php
include "config.php";
include "functions.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stmt = $conn->prepare("INSERT INTO salary_profiles (user_name, monthly_salary, fixed_needs, existing_debt, lifestyle_spending, monthly_savings, emergency_fund, dependents) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "sddddddi",
        $_POST['user_name'],
        $_POST['monthly_salary'],
        $_POST['fixed_needs'],
        $_POST['existing_debt'],
        $_POST['lifestyle_spending'],
        $_POST['monthly_savings'],
        $_POST['emergency_fund'],
        $_POST['dependents']
    );
    $stmt->execute();
    $profile_id = $stmt->insert_id;
    header("Location: commitments.php?profile_id=" . $profile_id);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Salary Profile - GajiPilot AI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "header.php"; ?>
<main>
    <div class="grid two">
        <div class="card">
            <h2>Salary Profile</h2>
            <p class="muted">Enter the user’s current financial situation before adding new commitments and goals.</p>

            <form method="POST" class="form">
                <div>
                    <label>Name</label>
                    <input type="text" name="user_name" placeholder="Enter your name" required>
                </div>
                <div>
                    <label>Monthly Net Salary</label>
                    <input type="number" name="monthly_salary" placeholder="e.g. 4200" step="0.01" required>
                </div>
                <div>
                    <label>Fixed Needs</label>
                    <input type="number" name="fixed_needs"  placeholder="e.g. 1450" step="0.01" required>

                </div>
                <div>
                    <label>Existing Debt</label>
                    <input type="number" name="existing_debt" placeholder="e.g. 700" step="0.01" required>
                </div>
                <div>
                    <label>Lifestyle Spending</label>
                    <input type="number" name="lifestyle_spending" placeholder="e.g. 850" step="0.01" required>
                </div>
                <div>
                    <label>Monthly Savings</label>
                    <input type="number" name="monthly_savings" placeholder="e.g. 600" step="0.01" required>
                </div>
                <div>
                    <label>Emergency Fund Now</label>
                    <input type="number" name="emergency_fund"  placeholder="e.g. 3500" step="0.01" required>
                </div>
                <div>
                    <label>Dependents</label>
                    <input type="number" name="dependents"  placeholder="e.g. 1" required>
                </div>

                <div style="grid-column:1/-1;">
                    <button class="btn primary" type="submit">Save Profile & Continue →</button>
                </div>
            </form>
        </div>

        <div class="card">
            <h2>What we check</h2>
            <div class="feature">✅ Commitment ratio</div>
            <div class="feature" style="margin-top:10px;">✅ Saving rate</div>
            <div class="feature" style="margin-top:10px;">✅ Emergency fund coverage</div>
            <div class="feature" style="margin-top:10px;">✅ Life goal affordability</div>
            <div class="feature" style="margin-top:10px;">✅ Safe / caution / risky decision</div>
        </div>
    </div>
</main>
</body>
</html>
