<!DOCTYPE html>
<html>
<head>
    <title>GajiPilot AI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "header.php"; ?>

<main>
    <section class="grid two" style="align-items:center;">
        <div>
            <div class="pill">✨ Track 1: Spend, save, and protect money</div>
            <h2 class="big">Test your salary before you commit.</h2>
            <p class="muted" style="font-size:18px;">
                GajiPilot AI helps employees check whether their salary can handle future commitments and life goals before making major financial decisions.
            </p>

            <div class="grid three" style="margin-top:18px;">
                <div class="feature">
                    <div class="icon">🧾</div>
                    <b>Salary Profile</b>
                    <p class="muted">Enter salary, needs, debt, savings, and emergency fund first.</p>
                </div>
                <div class="feature">
                    <div class="icon">➕</div>
                    <b>Commitment Builder</b>
                    <p class="muted">Add any loan, family support, takaful, or monthly bill.</p>
                </div>
                <div class="feature">
                    <div class="icon">🎯</div>
                    <b>Life Goals</b>
                    <p class="muted">Plan wedding, Umrah, education, house deposit, or emergency fund.</p>
                </div>
            </div>

            <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:24px;">
                <a class="btn primary" href="salary.php">Start Salary Check →</a>
            </div>
        </div>

        <div class="card">
            <div class="dark">
                <b style="color:#bfdbfe;">Start with your salary profile</b>
                <h2 style="color:white;">No results yet</h2>
                <p style="color:#cbd5e1;">
                    The system will only show percentages, score, and AI advice after the user enters salary details and saves a profile.
                </p>
                <a class="btn secondary" href="salary.php">Enter Salary Profile</a>
            </div>

            <div class="feature" style="margin-top:12px;">
                <b>✅ What we check later</b>
                <p class="muted">Commitment ratio, saving rate, emergency cover, life goal affordability, and safe/caution/risky decision.</p>
            </div>

            <div class="feature" style="margin-top:12px;">
                <b>💡 Why it starts empty</b>
                <p class="muted">Results such as 8%, 14%, or 51% only make sense after salary data is entered.</p>
            </div>
        </div>
    </section>
</main>
</body>
</html>