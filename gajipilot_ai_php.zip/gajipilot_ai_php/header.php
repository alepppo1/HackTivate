<?php
$current = basename($_SERVER['PHP_SELF']);
?>
<header>
    <div class="wrap top">
        <a class="brand" href="index.php">
            <div class="logo">💼</div>
            <div>
                <h1>GajiPilot AI</h1>
                <p>Test your salary before you commit</p>
            </div>
        </a>
        <nav>
            <a class="<?php echo $current == 'index.php' ? 'active' : ''; ?>" href="index.php">Home</a>
            <a class="<?php echo $current == 'salary.php' ? 'active' : ''; ?>" href="salary.php">Salary Profile</a>
            <a class="<?php echo $current == 'commitments.php' ? 'active' : ''; ?>" href="commitments.php">Commitments</a>
            <a class="<?php echo $current == 'goals.php' ? 'active' : ''; ?>" href="goals.php">Life Goals</a>
            <a class="<?php echo $current == 'result.php' ? 'active' : ''; ?>" href="result.php">Can I Commit?</a>
            <a class="<?php echo $current == 'coach.php' ? 'active' : ''; ?>" href="coach.php">AI Coach</a>
        </nav>
    </div>
</header>
