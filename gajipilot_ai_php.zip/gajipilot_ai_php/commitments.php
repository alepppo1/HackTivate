<?php
include "config.php";
include "functions.php";

$profile_id = $_GET['profile_id'] ?? null;

if (!$profile_id) {
    $latest = $conn->query("SELECT id FROM salary_profiles ORDER BY id DESC LIMIT 1")->fetch_assoc();
    $profile_id = $latest['id'] ?? null;
}

if (!$profile_id) {
    header("Location: salary.php");
    exit;
}

$profile_id = (int)$profile_id;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_id'])) {
        $delete_id = (int)$_POST['delete_id'];
        $conn->query("DELETE FROM commitments WHERE id = $delete_id AND profile_id = $profile_id");
    } else {
        $stmt = $conn->prepare("INSERT INTO commitments (profile_id, commitment_name, category, monthly_amount, duration_text) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "issds",
            $profile_id,
            $_POST['commitment_name'],
            $_POST['category'],
            $_POST['monthly_amount'],
            $_POST['duration_text']
        );
        $stmt->execute();
    }
}

$profile = $conn->query("SELECT * FROM salary_profiles WHERE id = $profile_id")->fetch_assoc();

if (!$profile) {
    header("Location: salary.php");
    exit;
}

$commitments = $conn->query("SELECT * FROM commitments WHERE profile_id = $profile_id ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);

/*
    Salary Plan section:
    This checks the user's current salary condition BEFORE adding new commitments.
    So we use empty commitment and goal arrays here.
*/
$emptyCommitments = [];
$emptyGoals = [];

$salaryPlan = calculateHealth($profile, $emptyCommitments, $emptyGoals);

$salary = (float)$profile['monthly_salary'];
$needsDebt = (float)$profile['fixed_needs'] + (float)$profile['existing_debt'];
$wants = (float)$profile['lifestyle_spending'];
$futureMoney = (float)$profile['monthly_savings'];

$needsDebtPercent = $salary > 0 ? ($needsDebt / $salary) * 100 : 0;
$wantsPercent = $salary > 0 ? ($wants / $salary) * 100 : 0;
$futurePercent = $salary > 0 ? ($futureMoney / $salary) * 100 : 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Commitments - GajiPilot AI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "header.php"; ?>

<main>

    <!-- Current Salary Plan -->
    <div class="card" style="margin-bottom:22px;">
        <h2>Current Salary Plan</h2>
        <p class="muted">
            This shows the user’s current salary condition before adding any new commitment.
        </p>

        <div class="grid two" style="margin-top:18px;">
            <div class="scorebox <?php echo getScoreClass($salaryPlan['score_before']); ?>">
                <b>Financial Health</b>
                <div class="score">
                    <?php echo $salaryPlan['score_before']; ?><span style="font-size:18px;">/100</span>
                </div>
                <b>Status: <?php echo getScoreStatus($salaryPlan['score_before']); ?></b>
            </div>

            <div class="grid two">
                <div class="stat">
                    Salary
                    <b><?php echo money($profile['monthly_salary']); ?></b>
                </div>

                <div class="stat">
                    Commitment Ratio
                    <b><?php echo percent($salaryPlan['dti_before']); ?></b>
                </div>

                <div class="stat">
                    Saving Rate
                    <b><?php echo percent($salaryPlan['save_before']); ?></b>
                </div>

                <div class="stat">
                    Emergency Cover
                    <b><?php echo number_format($salaryPlan['emergency_before'], 1); ?> months</b>
                </div>
            </div>
        </div>

        <div style="margin-top:24px;">
            <h2>Salary Allocation</h2>

            <div style="margin-top:18px;">
                <div style="display:flex;justify-content:space-between;font-weight:950;">
                    <span>🧾 Needs + Debt</span>
                    <span><?php echo money($needsDebt); ?> • <?php echo percent($needsDebtPercent); ?></span>
                </div>
                <div class="bar">
                    <div class="fill <?php echo $needsDebtPercent > 55 ? 'red' : ''; ?>" style="width:<?php echo min(100, $needsDebtPercent); ?>%;"></div>
                </div>
                <p class="muted">Ideal guide: around 50%</p>
            </div>

            <div style="margin-top:18px;">
                <div style="display:flex;justify-content:space-between;font-weight:950;">
                    <span>☕ Wants</span>
                    <span><?php echo money($wants); ?> • <?php echo percent($wantsPercent); ?></span>
                </div>
                <div class="bar">
                    <div class="fill <?php echo $wantsPercent > 35 ? 'red' : ''; ?>" style="width:<?php echo min(100, $wantsPercent); ?>%;"></div>
                </div>
                <p class="muted">Ideal guide: around 30%</p>
            </div>

            <div style="margin-top:18px;">
                <div style="display:flex;justify-content:space-between;font-weight:950;">
                    <span>🐷 Future Money</span>
                    <span><?php echo money($futureMoney); ?> • <?php echo percent($futurePercent); ?></span>
                </div>
                <div class="bar">
                    <div class="fill <?php echo $futurePercent < 10 ? 'red' : ''; ?>" style="width:<?php echo min(100, $futurePercent); ?>%;"></div>
                </div>
                <p class="muted">Ideal guide: around 20%</p>
            </div>
        </div>
    </div>

    <!-- Commitment Builder -->
    <div class="grid two">
        <div class="card">
            <h2>Commitment Builder</h2>
            <p class="muted">
                Add any monthly commitment the user wants to test.
            </p>

            <form method="POST" class="form">
                <div>
                    <label>Commitment Name</label>
                    <input name="commitment_name" placeholder="e.g. Car Loan" required>
                </div>

                <div>
                    <label>Monthly Amount</label>
                    <input type="text" inputmode="decimal" name="monthly_amount" placeholder="e.g. 750" required>
                </div>

                <div>
                    <label>Category</label>
                    <select name="category">
                        <option>Loan</option>
                        <option>Family</option>
                        <option>Protection</option>
                        <option>Installment</option>
                        <option>Education</option>
                        <option>Custom</option>
                    </select>
                </div>

                <div>
                    <label>Duration</label>
                    <input name="duration_text" placeholder="e.g. 7 years / Ongoing">
                </div>

                <div style="grid-column:1/-1;">
                    <button class="btn primary" type="submit">Add Commitment</button>
                </div>
            </form>

            <div style="margin-top:18px;">
                <a class="btn secondary" href="goals.php?profile_id=<?php echo $profile_id; ?>">
                    Continue to Life Goals →
                </a>
            </div>
        </div>

        <div class="card">
            <h2>Commitments to Test</h2>

            <?php if (empty($commitments)): ?>
                <p class="muted">
                    No commitments yet. Add one to test the salary impact.
                </p>
            <?php endif; ?>

            <?php foreach ($commitments as $c): ?>
                <div class="item">
                    <div>
                        <b><?php echo htmlspecialchars($c['commitment_name']); ?></b>
                        <div class="muted">
                            <?php echo htmlspecialchars($c['category']); ?> •
                            <?php echo htmlspecialchars($c['duration_text']); ?>
                        </div>
                    </div>

                    <div class="item-actions">
                        <b><?php echo money($c['monthly_amount']); ?></b>

                        <form method="POST" style="margin:0;">
                            <input type="hidden" name="delete_id" value="<?php echo $c['id']; ?>">
                            <button class="delete" type="submit">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</main>
</body>
</html>