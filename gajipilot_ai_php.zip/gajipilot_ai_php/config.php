<?php
// GajiPilot AI database configuration
// Change these values if your MySQL username/password is different.
$host = "localhost";
$user = "root";
$password = "";
$database = "gajipilot_ai";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
