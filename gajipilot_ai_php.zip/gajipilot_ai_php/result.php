<?php
include "config.php";
include "functions.php";

$profile_id = $_GET['profile_id'] ?? null;
if (!$profile_id) {
    $latest = $conn->query("SELECT id FROM salary_profiles ORDER BY id DESC LIMIT 1")->fetch_assoc();
    $profile_id = $latest['id'] ?? null;
}

if (!$profile_id) {
    header("Location: salary.php");
    exit;
}

$profile = $conn->query("SELECT * FROM salary_profiles WHERE id = $profile_id")->fetch_assoc();
$commitments = $conn->query("SELECT * FROM commitments WHERE profile_id = $profile_id")->fetch_all(MYSQLI_ASSOC);
$goals = $conn->query("SELECT * FROM life_goals WHERE profile_id = $profile_id")->fetch_all(MYSQLI_ASSOC);
$health = calculateHealth($profile, $commitments, $goals);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Can I Commit? - GajiPilot AI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "header.php"; ?>
<main>
    <div class="card">
        <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
            <div>
                <h2>Can I Commit?</h2>
                <p class="muted">Check whether your salary can handle your new commitments and life goals.</p>
            </div>
            <span class="badge d<?php echo $health['status']; ?>">Decision: <?php echo $health['status']; ?></span>
        </div>

        <div class="grid two" style="margin-top:18px;">
            <div class="card" style="box-shadow:none;background:#f8fafc;">
                <h2>Before Commitment</h2>
                <div class="grid two">
                    <div class="stat">Score<b><?php echo $health['score_before']; ?>/100</b></div>
                    <div class="stat">Commitment Ratio<b><?php echo percent($health['dti_before']); ?></b></div>
                    <div class="stat">Saving Rate<b><?php echo percent($health['save_before']); ?></b></div>
                    <div class="stat">Emergency Cover<b><?php echo number_format($health['emergency_before'], 1); ?> months</b></div>
                </div>
                <div class="stat" style="margin-top:12px;background:white;">
                    Monthly Pressure<b><?php echo money($health['before_commitment']); ?></b>
                </div>
            </div>

            <div class="card" style="box-shadow:none;background:#dbeafe;">
                <h2>After Commitment + Goals</h2>
                <div class="grid two">
                    <div class="stat">Score<b><?php echo $health['score_after']; ?>/100</b></div>
                    <div class="stat">Commitment Ratio<b><?php echo percent($health['dti_after']); ?></b></div>
                    <div class="stat">Saving Rate<b><?php echo percent($health['save_after']); ?></b></div>
                    <div class="stat">Emergency Cover<b><?php echo number_format($health['emergency_after'], 1); ?> months</b></div>
                </div>
                <div class="stat" style="margin-top:12px;background:white;">
                    Monthly Pressure<b><?php echo money($health['total_monthly_pressure_after']); ?></b>
                </div>
            </div>
        </div>
    </div>

    <div class="grid two" style="margin-top:20px;">
        <div class="card">
            <h2>Items Tested</h2>

            <h3>Commitments</h3>
            <?php if (empty($commitments)): ?>
                <p class="muted">No commitments added.</p>
            <?php endif; ?>
            <?php foreach ($commitments as $c): ?>
                <div class="item">
                    <b><?php echo htmlspecialchars($c['commitment_name']); ?></b>
                    <b><?php echo money($c['monthly_amount']); ?>/month</b>
                </div>
            <?php endforeach; ?>

            <h3 style="margin-top:20px;">Life Goals</h3>
            <?php if (empty($goals)): ?>
                <p class="muted">No goals added.</p>
            <?php endif; ?>
            <?php foreach ($goals as $g): ?>
                <div class="item">
                    <b><?php echo htmlspecialchars($g['goal_name']); ?></b>
                    <b><?php echo money(calculateMonthlyGoal($g)); ?>/month</b>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card">
            <h2>AI Decision Summary</h2>
            <p class="muted">
                Your new commitments add <b><?php echo money($health['total_new_commitment']); ?></b> monthly.
                Your life goals need <b><?php echo money($health['total_goal_saving']); ?></b> monthly.
                Commitment ratio changes from <b><?php echo percent($health['dti_before']); ?></b> to
                <b><?php echo percent($health['dti_after']); ?></b>.
                Emergency cover changes from <b><?php echo number_format($health['emergency_before'], 1); ?></b>
                to <b><?php echo number_format($health['emergency_after'], 1); ?></b> months.
            </p>

            <div class="feature">
                <b>Recommended safer monthly limit</b>
                <h2><?php echo money($health['max_recommended']); ?>/month</h2>
            </div>

            <div style="margin-top:18px;">
                <a class="btn primary" href="coach.php?profile_id=<?php echo $profile_id; ?>">Open AI Coach →</a>
            </div>
        </div>
    </div>
</main>
</body>
</html>
