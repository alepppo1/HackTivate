<?php
include "config.php";
include "functions.php";

$profile_id = $_GET['profile_id'] ?? null;
if (!$profile_id) {
    $latest = $conn->query("SELECT id FROM salary_profiles ORDER BY id DESC LIMIT 1")->fetch_assoc();
    $profile_id = $latest['id'] ?? null;
}

if (!$profile_id) {
    header("Location: salary.php");
    exit;
}

$profile = $conn->query("SELECT * FROM salary_profiles WHERE id = $profile_id")->fetch_assoc();
$commitments = $conn->query("SELECT * FROM commitments WHERE profile_id = $profile_id")->fetch_all(MYSQLI_ASSOC);
$goals = $conn->query("SELECT * FROM life_goals WHERE profile_id = $profile_id")->fetch_all(MYSQLI_ASSOC);
$health = calculateHealth($profile, $commitments, $goals);
$advice = generateCoachAdvice($health);

$title = "This plan looks manageable.";
if ($health['status'] == "Caution") $title = "Possible, but your margin is thin.";
if ($health['status'] == "Risky") $title = "This plan may hurt your salary.";
?>
<!DOCTYPE html>
<html>
<head>
    <title>AI Coach - GajiPilot AI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "header.php"; ?>
<main>
    <div class="grid two">
        <div class="card">
            <h2>AI Money Coach</h2>
            <p class="muted">Simple explanation, not finance jargon.</p>

            <div class="dark">
                <b style="color:#ddd6fe;">Personal Diagnosis</b>
                <h2 style="color:white;margin-top:10px;"><?php echo $title; ?></h2>
                <p style="color:#cbd5e1;">
                    After adding <?php echo money($health['total_new_commitment']); ?> commitments and
                    <?php echo money($health['total_goal_saving']); ?> goal savings, your score becomes
                    <?php echo $health['score_after']; ?>/100 and your saving rate becomes <?php echo percent($health['save_after']); ?>.
                </p>
            </div>

            <?php foreach ($advice as $a): ?>
                <div class="coach <?php echo $a['type']; ?>">
                    <b><?php echo $a['type'] == 'good' ? '✅' : '⚠️'; ?> <?php echo $a['title']; ?></b>
                    <p class="muted"><?php echo $a['text']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card">
            <h2>Safer Alternatives</h2>

            <div class="coach good">
                <b>🎯 Reduce monthly commitment</b>
                <p class="muted">Try keeping new commitments near <?php echo money($health['max_recommended']); ?>/month.</p>
            </div>

            <div class="coach good">
                <b>📅 Extend goal timeline</b>
                <p class="muted">If goal saving is too high, extend the goal duration to lower monthly pressure.</p>
            </div>

            <div class="coach good">
                <b>🐷 Build emergency fund first</b>
                <p class="muted">Aim for at least <?php echo money($health['after_commitment'] * 3); ?> emergency fund before adding big commitments.</p>
            </div>

            <div class="coach good">
                <b>📉 Delay and prepare</b>
                <p class="muted">Delay the biggest commitment for 3–6 months while reducing existing debt.</p>
            </div>
        </div>
    </div>
</main>
</body>
</html>
