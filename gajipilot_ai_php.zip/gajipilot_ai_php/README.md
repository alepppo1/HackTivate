# GajiPilot AI: Can I Commit?

## Track
Track 1 – Reimagine Money

## Project Idea
GajiPilot AI helps employees check whether their salary can handle future commitments and life goals before making major financial decisions.

The app is not just a financing calculator. It checks the user's whole salary situation:
- salary
- fixed needs
- existing debt
- lifestyle spending
- savings
- emergency fund
- dependents
- new commitments
- life goals

## Main Features
1. Salary Profile
2. Commitment Builder
3. Life Goals Planner
4. Can I Commit? Result
5. AI Money Coach

## Tech Stack
- PHP
- MySQL
- HTML/CSS

## Setup Instructions

### 1. Put project folder in XAMPP
Copy the `gajipilot_ai_php` folder into:

```text
C:/xampp/htdocs/
```

### 2. Start XAMPP
Start:
- Apache
- MySQL

### 3. Create database
Open phpMyAdmin:

```text
http://localhost/phpmyadmin
```

Import the file:

```text
database.sql
```

### 4. Run project
Open browser:

```text
http://localhost/gajipilot_ai_php/
```

## AI Logic
The prototype uses explainable rule-based AI logic. It calculates:
- commitment ratio
- saving rate
- emergency fund coverage
- monthly goal saving
- before vs after score

The AI Coach converts the calculations into simple financial advice.

## AI Tools Used
- ChatGPT for idea development, prototype planning, and code assistance
- Rule-based AI logic in prototype for explainable financial advice
